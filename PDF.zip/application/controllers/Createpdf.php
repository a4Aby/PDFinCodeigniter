<?php
class Createpdf extends CI_Controller {
	

public function pdf()
{
    $this->load->helper('pdf_helper');
    $data['title']="Title";
    $data['content']="aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";
    
    $this->load->view('pdfreport', $data);
}
}